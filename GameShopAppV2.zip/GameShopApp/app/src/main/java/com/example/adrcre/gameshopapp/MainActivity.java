package com.example.adrcre.gameshopapp;

import android.app.ListActivity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends ListActivity {

    public static final int NEW_ITEM = 1;
    public static final int SHOW_ITEM = 2;

    private DBHelper dbHelper1;

    //elemento seleccionado
    private int myLastRowSelected = 0;
    public static DBHelper myDbHelper = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Button botStart = (Button) findViewById(R.id.bitCrear);
        Button botUpdate= (Button) findViewById(R.id.botActualizar);
        Button botBorrar = (Button)findViewById(R.id.botBorrar);
        Button botPrecio = (Button)findViewById(R.id.botPrecioTot);

        myDbHelper = new DBHelper(this);
        myDbHelper.open();

        try {
            introDatos();
        } catch (android.database.SQLException e) {
            e.printStackTrace();
        }

        //TODO Aqui para pasar objetos de la clase seleccionada

        /*
        botStart.setOnClickListener(new View.OnClickListener(){
            public void onClick(View v){
                Intent intent = new Intent (MainActivity.this,Item.class);
                startActivityForResult(intent, NEW_ITEM);
            }
        });
        */


        botUpdate.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivityForResult(intent, SHOW_ITEM);
            }
        });

        botBorrar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                myDbHelper.drop();
                Toast.makeText(MainActivity.this, "Datos Borrados", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivityForResult(intent, SHOW_ITEM);
            }
        });

        botPrecio.setOnClickListener(new View.OnClickListener() {
            public void onClick(View view) {
                ListaDatos listaDatos = null;
                int precio = listaDatos.precio;
                String precFin = myDbHelper.price(precio);
                Toast.makeText(MainActivity.this, "Precio total: "+precFin, Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, MainActivity.class);
                startActivityForResult(intent, SHOW_ITEM);
            }
        });

        Button botonFactura=findViewById(R.id.botJuegos);
        botonFactura.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(MainActivity.this, RealizarPedidos.class);
                startActivity(intent);
            }
        });

    }
    private void showMessage(int message){
        Context context = getApplicationContext();
        CharSequence text = getResources().getString(message);
        int duration = Toast.LENGTH_SHORT;
        Toast toast = Toast.makeText(context, text, duration);
        toast.show();
    }


    //TODO MIRARA AQUÏI PARA SUMAR PRECIO JUEGO A TABLA PEDIDO
    private void introDatos() {
        myDbHelper.open();
        Cursor cursor = myDbHelper.getItems();
        ListaDatos listaDatos = null;
        ArrayList<ListaDatos> arrayListaDatos = new ArrayList<ListaDatos>();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(cursor.getColumnIndex(DBHelper.TABLE_JUEGOS_ID));
            String nombre = cursor.getString(cursor.getColumnIndex(DBHelper.TABLE_JUEGOS_NOMBRE));
            //String marca = cursor.getString(cursor.getColumnIndex(DBHelper.TABLE_JUEGOS_MARCA));
            int precio = cursor.getInt(cursor.getColumnIndex(DBHelper.TABLE_JUEGOS_PRECIO));
            int id_juego = cursor.getInt(cursor.getColumnIndex(DBHelper.TABLE_JUEGOS_ID_JUEGO));

            listaDatos = new ListaDatos();
            listaDatos.id = id;
            listaDatos.nombre = nombre;
            //listaDatos.marca = marca;
            listaDatos.precio = precio;
            listaDatos.id_juego = id_juego;

            arrayListaDatos.add(listaDatos);
        }

        cursor.close();
        myDbHelper.close();

        AdaptarTareas objects = new AdaptarTareas(this, R.layout.lista, arrayListaDatos, getLayoutInflater() );
        setListAdapter(objects);
        //TODO setListAdapter ENCONTRAR
    }

/*
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.nuevoObjeto:
                Intent intent = new Intent (this,Item.class);
                startActivityForResult(intent, NEW_ITEM);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
    */

    private class ListaDatos {
        String nombre, marca;
        int id, precio, id_juego;
    }

    private class AdaptarTareas extends ArrayAdapter<ListaDatos> {
        private LayoutInflater inflater;
        private List<ListaDatos> myLista;

        private AdaptarTareas(Context context, int resource, List<ListaDatos> lista, LayoutInflater inflater) {
            super(context, resource, lista);
            this.inflater = inflater;
            this.myLista = lista;
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            ListaDatos listEntry = myLista.get(position);
            // obtención de la vista de la línea de la tabla
            View row = inflater.inflate(R.layout.lista, null);
            //TODO Localizar y cambiar Datos
            TextView nombre = (TextView) row.findViewById(R.id.rNombre);
            TextView price = (TextView) row.findViewById(R.id.rPrecio);
            ImageView icon = (ImageView) row.findViewById(R.id.rID);

            nombre.setText(listEntry.nombre);



            // dependiendo del id del juego, se muestran distintas imagenes

            icon.setTag(new Integer(listEntry.id));
            switch (listEntry.id_juego) {
                case 1:
                    icon.setImageResource(R.drawable.bloodborne);
                    break;
                case 2:
                    icon.setImageResource(R.drawable.gow);
                    break;
                case 3:
                    icon.setImageResource(R.drawable.rdr2);
                    break;
                case 4:
                    icon.setImageResource(R.drawable.spiderman);
                    break;
                case 5:
                    icon.setImageResource(R.drawable.mario);
                    break;
                case 6:
                    icon.setImageResource(R.drawable.forza);
                    break;
                case 7:
                    icon.setImageResource(R.drawable.halo);
                    break;
                default:
                    icon.setImageResource(R.drawable.spiderman);
                    break;
            }
            return row;
        }


    }

//TODO CAMBIAR Y REVISAR NOMBRES DE TODAS LAS CLASES Y LAYOUTS
    //TODO PONER PRECIO VISIBLE EN ROW_LIST LAYOUT

}
