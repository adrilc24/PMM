package com.example.adrcre.gameshopapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;


public class DBHelper {
    private Context myContext = null;
    private DataBaseHelperInternal myDBHelper = null;
    private SQLiteDatabase myDataBase = null;
    private static final String DATABASE_NAME = "Juegos";
    private static final int DB_VERSION = 8;
    // tabla y campos
    private static final String TABLE_NAME_JUEGOS = "Juegos";
    public static final String TABLE_JUEGOS_ID = "id";
    public static final String TABLE_JUEGOS_NOMBRE = "nombre";
    public static final String TABLE_JUEGOS_MARCA = "marca";
    public static final String TABLE_JUEGOS_PRECIO = "precio";
    public static final String TABLE_JUEGOS_ID_JUEGO = "id_juego";

    private static final String TABLE_NAME_PEDIDO = "pedido";
    public static final String TABLE_PEDIDO_ID = "id";
    public static final String TABLE_PEDIDO_NOMBRE = "nombre";
    public static final String TABLE_PEDIDO_PRECIO = "precio";

    private static final String TABLE_NAME_USERS = "usuarios";
    public static final String TABLE_USERS_ID = "id";
    public static final String TABLE_USERS_NOMBRE = "nombre";
    public static final String TABLE_USERS_PWD = "password";



    // SQL de creación de la tabla
    private static final String CREATE_TABLE_JUEGOS =
            "create table "+ TABLE_NAME_JUEGOS +" ("+ TABLE_JUEGOS_ID +" integer primary key, "+ TABLE_JUEGOS_NOMBRE +" text not null, "+ TABLE_JUEGOS_PRECIO +" integer not null, "
                    + TABLE_JUEGOS_ID_JUEGO +" integer not null, "+ TABLE_JUEGOS_MARCA +" text)";
    private static final String CREATE_TABLE_PEDIDOS =
            "create table "+ TABLE_NAME_PEDIDO +" ("+ TABLE_PEDIDO_ID +" integer primary key, "+ TABLE_PEDIDO_NOMBRE +" text not null, "
                    + TABLE_PEDIDO_PRECIO +" integer not null )";
    private static final String CREATE_TABLE_USERS =
            "create table "+ TABLE_NAME_USERS +" ("+ TABLE_USERS_ID +" integer primary key, "+ TABLE_USERS_NOMBRE +" text not null, "
                    + TABLE_USERS_PWD +" text not null )";
    //constructor
    public DBHelper(Context ctx) {
        this.myContext = ctx;
    }
    //clase privada para control de la SQLite
    private static class DataBaseHelperInternal extends SQLiteOpenHelper {
        public DataBaseHelperInternal(Context context) {
            super(context, DATABASE_NAME, null, DB_VERSION);		}

        @Override
        public void onCreate(SQLiteDatabase db) {
            createTables(db);
        }
        @Override
        public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
            deleteTables(db);
            createTables(db);
            //sumPedido(db);
        }
        private void createTables(SQLiteDatabase db) {
            db.execSQL(CREATE_TABLE_JUEGOS);
            db.execSQL(CREATE_TABLE_PEDIDOS);
        }

        private void deleteTables(SQLiteDatabase db) {
            db.execSQL("DROP TABLE IF EXISTS " + DBHelper.TABLE_NAME_JUEGOS);
            db.execSQL("DROP TABLE IF EXISTS " + DBHelper.TABLE_NAME_PEDIDO);
            db.execSQL("DROP TABLE IF EXISTS " + DBHelper.TABLE_NAME_USERS);
        }

        /*
        private void sumPedido(SQLiteDatabase db) {
            db.execSQL("UPDATE "+DBHelper.TABLE_NAME_PEDIDO + " SET " + DBHelper.TABLE_PEDIDO_PRECIO + " = " + DBHelper.TABLE_PEDIDO_PRECIO + TABLE_JUEGOS_PRECIO);
        }
        */

    }

    //TODO Cambiar nombres de aqui para abajo
    public DBHelper open()  {
        myDBHelper = new DataBaseHelperInternal(myContext);
        myDataBase = myDBHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        myDBHelper.close();
    }

    //obtener todos los elementos
    public Cursor getItems() {
        //Parametros:nombreTabla,campos,campoWhere,condicionWhere,Group By, Havong, Order by
        return myDataBase.query(TABLE_NAME_JUEGOS, new String[] {TABLE_JUEGOS_ID, TABLE_JUEGOS_NOMBRE, TABLE_JUEGOS_PRECIO, TABLE_JUEGOS_ID_JUEGO}, null, null, null, null, TABLE_JUEGOS_ID_JUEGO);
    }

    //crear elemento
    public long insertJuegos(String nombre, String precio, String marca, String id_juego){
        ContentValues initialValues = new ContentValues();
        initialValues.put(TABLE_JUEGOS_ID_JUEGO, id_juego);
        initialValues.put(TABLE_JUEGOS_NOMBRE, nombre);
        initialValues.put(TABLE_JUEGOS_PRECIO, precio);
        initialValues.put(TABLE_JUEGOS_MARCA, marca);
        return myDataBase.insert(TABLE_NAME_JUEGOS, null, initialValues);
    }

    public void insertUsers(String username, String password, int id){
        ContentValues initialValues = new ContentValues();
        initialValues.put(TABLE_USERS_ID, id);
        initialValues.put(TABLE_USERS_NOMBRE, username);
        initialValues.put(TABLE_USERS_PWD, password);
        myDataBase.insert(TABLE_NAME_USERS,null,initialValues);
        myDataBase.close();
    }

    public void insertPedidos(int precio){
        ContentValues initialValues = new ContentValues();
        initialValues.put(TABLE_PEDIDO_PRECIO, precio);
        myDataBase.insert(TABLE_NAME_PEDIDO,null,initialValues);
        myDataBase.close();
    }

    public  String LoginIn(String Username){

        String  query="SELECT UserName,Password FROM  "+TABLE_NAME_USERS;
        Cursor corsor=myDataBase.rawQuery(query,null);
        String username,password;
        password="Not found";
        if(corsor.moveToFirst()){
            do{
                username=corsor.getString(0);
                if(username.contentEquals(Username)){
                    password=corsor.getString(1);
                    break;
                }
            }while (corsor.moveToNext());
        }
        return  password;
    }
    public void drop(){
        this.myContext.deleteDatabase(DATABASE_NAME);
    }

    public String price(int precio) {
        String selectQuery = "SELECT SUM("+precio+") INTO "+TABLE_PEDIDO_PRECIO;
        Cursor cursor = myDataBase.rawQuery(selectQuery, null);
        cursor.close();
        return TABLE_PEDIDO_PRECIO;
    }

}