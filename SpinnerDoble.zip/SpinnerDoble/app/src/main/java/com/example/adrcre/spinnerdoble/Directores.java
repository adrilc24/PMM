package com.example.adrcre.spinnerdoble;

public class Directores {
    public String nombre;

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public Directores(String nombre){
        this.nombre = nombre;
    }
}
