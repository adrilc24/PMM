package com.example.adrcre.gameshopapp;

import android.app.Activity;
import android.content.Intent;
import android.database.SQLException;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class RegistroUsers extends Activity {
    private Button btInicioSesion;
    private Button btRegistro;
    private EditText nomUser = null;
    private EditText passUser = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user1);


        btInicioSesion = findViewById(R.id.botIniSesion);
        btRegistro = findViewById(R.id.botRegistro);

        final DBHelper dbHelper = new DBHelper(this);

        btRegistro.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                nomUser = (EditText) findViewById(R.id.textUsuario);
                passUser = (EditText) findViewById(R.id.textPassword);

                String nombre = nomUser.getText().toString();
                String password = passUser.getText().toString();
                double id = Math.random()*100;
                String user_id = String.valueOf(id);

                if (!emptyValidation()) {

                    try {
                        MainActivity.myDbHelperUser.open();
                        MainActivity.myDbHelperUser.insertUsers(user_id, nombre, password);
                        MainActivity.myDbHelperUser.close();
                    } catch (SQLException e) {
                        e.printStackTrace();
                    }
                }else{
                    Toast.makeText(RegistroUsers.this, "Empty Fields", Toast.LENGTH_SHORT).show();
                }
            }
        });
        btInicioSesion.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!emptyValidation()) {
                    Usuario user = (Usuario) dbHelper.getUsers();
                    if (user != null) {
                        Bundle mBundle = new Bundle();
                        mBundle.putString("user", user.getUsername());
                        Intent intent = new Intent(RegistroUsers.this, MainActivity.class);
                        intent.putExtras(mBundle);
                        startActivity(intent);
                        Toast.makeText(RegistroUsers.this, "Bienvenido " + user.getUsername(), Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(RegistroUsers.this, "Este usuario no existe", Toast.LENGTH_SHORT).show();
                        passUser.setText("");
                    }
                }else{
                    Toast.makeText(RegistroUsers.this, "Campo vacío", Toast.LENGTH_SHORT).show();
                }
            }
        });


    }
/*
    protected  void saveRegistroUsuario() {

        nomUser = (EditText) findViewById(R.id.textUsuario);
        passUser = (EditText) findViewById(R.id.textPassword);

        String nombre = nomUser.getText().toString();
        String pass = passUser.getText().toString();
        String id = "4";

        if (!emptyValidation()) {

            try {
                UserActivity.myDbHelper.open();
                UserActivity.myDbHelper.insertUsers(id, nombre, pass);
                UserActivity.myDbHelper.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }else{
            Toast.makeText(RegistroUsers.this, "Empty Fields", Toast.LENGTH_SHORT).show();
        }
    }

    */
    private boolean emptyValidation() {
        if (TextUtils.isEmpty(nomUser.getText().toString()) || TextUtils.isEmpty(passUser.getText().toString())) {
            return true;
        }else {
            return false;
        }
    }
}
